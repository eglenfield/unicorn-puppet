$(document).ready(function() {
    $('.chart-container').on('mousedown', function(event) {
       console.log("HEYHEYD");
    });
});